2. Create an interface called "BankAccount" with methods called "deposit" and "withdraw". Create a class called "CheckingAccount" that implements the BankAccount interface and implements the "deposit" and "withdraw" methods. Create an object of the CheckingAccount class and call both the "deposit" and "withdraw" methods.

Code:-

// Define the BankAccount interface
interface BankAccount {
    void deposit(double amount);
    void withdraw(double amount);
}

// Implement the BankAccount interface in the CheckingAccount class
class CheckingAccount implements BankAccount {
    private double balance;

    // Constructor to initialize balance
    public CheckingAccount(double initialBalance) {
        this.balance = initialBalance;
    }

    // Implement the deposit method
    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: $" + amount);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    // Implement the withdraw method
    @Override
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew: $" + amount);
        } else if (amount > balance) {
            System.out.println("Insufficient funds.");
        } else {
            System.out.println("Withdrawal amount must be positive.");
        }
    }

    // Method to check the current balance
    public double getBalance() {
        return balance;
    }
}

public class BankSystem {
    public static void main(String[] args) {
        // Create an instance of CheckingAccount
        CheckingAccount account = new CheckingAccount(1000.0); // Initial balance of $1000

        // Call the deposit method
        account.deposit(200.0); // Output: Deposited: $200.0

        // Call the withdraw method
        account.withdraw(150.0); // Output: Withdrew: $150.0

        // Check the current balance
        System.out.println("Current balance: $" + account.getBalance()); // Output: Current balance: $1050.0

        // Try to withdraw more than the balance
        account.withdraw(2000.0); // Output: Insufficient funds.

        // Try to deposit a negative amount
        account.deposit(-50.0); // Output: Deposit amount must be positive.

        // Try to withdraw a negative amount
        account.withdraw(-100.0); // Output: Withdrawal amount must be positive.
    }
}

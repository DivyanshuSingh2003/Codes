4. Write a Java program to create a class known as Person with methods called getFirstName() and getLastName().
Create a class Employee extends Person with its own methods like getSalary().
Create a class Manager extends Employee with its own method getPost().
Create a class citizen extends Person with its own method getCitizenship().
Show single, multi level and hirarchical inheritance.

Code:-

// Base class Person
class Person {
    private String firstName;
    private String lastName;

    // Constructor to initialize Person
    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Method to get first name
    public String getFirstName() {
        return firstName;
    }

    // Method to get last name
    public String getLastName() {
        return lastName;
    }
}

// Single inheritance: Employee extends Person
class Employee extends Person {
    private double salary;

    // Constructor to initialize Employee
    public Employee(String firstName, String lastName, double salary) {
        super(firstName, lastName);
        this.salary = salary;
    }

    // Method to get salary
    public double getSalary() {
        return salary;
    }
}

// Multilevel inheritance: Manager extends Employee
class Manager extends Employee {
    private String post;

    // Constructor to initialize Manager
    public Manager(String firstName, String lastName, double salary, String post) {
        super(firstName, lastName, salary);
        this.post = post;
    }

    // Method to get post
    public String getPost() {
        return post;
    }
}

// Hierarchical inheritance: Citizen extends Person
class Citizen extends Person {
    private String citizenship;

    // Constructor to initialize Citizen
    public Citizen(String firstName, String lastName, String citizenship) {
        super(firstName, lastName);
        this.citizenship = citizenship;
    }

    // Method to get citizenship
    public String getCitizenship() {
        return citizenship;
    }
}

public class Main {
    public static void main(String[] args) {
        // Single inheritance example
        Employee employee = new Employee("John", "Doe", 50000);
        System.out.println("Employee Name: " + employee.getFirstName() + " " + employee.getLastName());
        System.out.println("Employee Salary: $" + employee.getSalary());

        // Multilevel inheritance example
        Manager manager = new Manager("Alice", "Smith", 80000, "Project Manager");
        System.out.println("\nManager Name: " + manager.getFirstName() + " " + manager.getLastName());
        System.out.println("Manager Salary: $" + manager.getSalary());
        System.out.println("Manager Post: " + manager.getPost());

        // Hierarchical inheritance example
        Citizen citizen = new Citizen("Bob", "Johnson", "USA");
        System.out.println("\nCitizen Name: " + citizen.getFirstName() + " " + citizen.getLastName());
        System.out.println("Citizen Citizenship: " + citizen.getCitizenship());
    }
}

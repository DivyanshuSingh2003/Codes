3.   Write a class with the name Perimeter using function overload that computes the perimeter of a square, a rectangle and a circle.

Code:-

public class Perimeter {

    // Method to compute the perimeter of a square
    public double compute(double side) {
        return 4 * side;
    }

    // Method to compute the perimeter of a rectangle
    public double compute(double length, double breadth) {
        return 2 * (length + breadth);
    }

    // Method to compute the perimeter of a circle
    public double compute(double radius, boolean isCircle) {
        // We use the value 22/7 as an approximation for pi
        return 2 * (22.0 / 7.0) * radius;
    }

    public static void main(String[] args) {
        Perimeter perimeterCalculator = new Perimeter();

        // Compute and print the perimeter of a square with side 5
        double squarePerimeter = perimeterCalculator.compute(5.0);
        System.out.println("Perimeter of the square: " + squarePerimeter); // Output: 20.0

        // Compute and print the perimeter of a rectangle with length 5 and breadth 3
        double rectanglePerimeter = perimeterCalculator.compute(5.0, 3.0);
        System.out.println("Perimeter of the rectangle: " + rectanglePerimeter); // Output: 16.0

        // Compute and print the perimeter of a circle with radius 7
        double circlePerimeter = perimeterCalculator.compute(7.0, true);
        System.out.println("Perimeter of the circle: " + circlePerimeter); // Output: 44.0
    }
}

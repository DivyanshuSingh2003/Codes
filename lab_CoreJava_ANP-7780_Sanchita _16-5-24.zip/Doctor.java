1.Create a class Doctor add method surgery(),extend Surgeon from this and inherit the method , create class Nurse extending doctor and add ,method treatement().

Code:-


// Base class Doctor
class Doctor {
    // Method in Doctor class
    public void surgery() {
        System.out.println("Performing surgery");
    }
}

// Surgeon class extending Doctor
class Surgeon extends Doctor {
    // Inherits the surgery method from Doctor
}

// Nurse class extending Doctor
class Nurse extends Doctor {
    // Additional method in Nurse class
    public void treatment() {
        System.out.println("Providing treatment");
    }
}

public class Hospital {
    public static void main(String[] args) {
        // Create an instance of Surgeon and call surgery method
        Surgeon surgeon = new Surgeon();
        surgeon.surgery(); // Output: Performing surgery

        // Create an instance of Nurse and call both methods
        Nurse nurse = new Nurse();
        nurse.surgery(); // Output: Performing surgery
        nurse.treatment(); // Output: Providing treatment
    }
}

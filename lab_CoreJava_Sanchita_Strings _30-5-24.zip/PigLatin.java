1.In Piglatin a word such as KING becomes INGKAY, TROUBLE becomes OUBLETRAY as so on. The first vowel of the original word becomes the starting of the translation and proceeding letter being shifted towards the end and followed by AY. Word that begins with a vowel is left unchanged. WAP to accept a word and convert in to Piglatin word.

Code:- 

import java.util.Scanner;

public class PigLatin {

    // Function to check if a character is a vowel
    private static boolean isVowel(char ch) {
        ch = Character.toLowerCase(ch);
        return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
    }

    // Function to convert a word to PigLatin
    public static String toPigLatin(String word) {
        // Check if the word starts with a vowel
        if (isVowel(word.charAt(0))) {
            return word;
        }

        // Find the index of the first vowel
        int firstVowelIndex = -1;
        for (int i = 0; i < word.length(); i++) {
            if (isVowel(word.charAt(i))) {
                firstVowelIndex = i;
                break;
            }
        }

        // If there is no vowel in the word, return the word followed by "AY"
        if (firstVowelIndex == -1) {
            return word + "AY";
        }

        // Form the Pig Latin word
        String pigLatinWord = word.substring(firstVowelIndex) + word.substring(0, firstVowelIndex) + "AY";
        return pigLatinWord;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a word: ");
        String word = scanner.next();
        String pigLatinWord = toPigLatin(word);
        System.out.println("Pig Latin: " + pigLatinWord);
        scanner.close();
    }
}
3. Write a program for converting a sentence in reverse. (Input: BASIC IS PROGRAMMING | Output: PROGRAMMING IS BASIC)

Code:-

public class ReverseSentence {
    public static void main(String[] args) {
        // Input sentence
        String sentence = "BASIC IS PROGRAMMING";

        // Split the sentence into words
        String[] words = sentence.split(" ");

        // Initialize a StringBuilder to hold the reversed sentence
        StringBuilder reversedSentence = new StringBuilder();

        // Loop through the words array in reverse order
        for (int i = words.length - 1; i >= 0; i--) {
            reversedSentence.append(words[i]);

            // Add a space between words, except for the last word
            if (i > 0) {
                reversedSentence.append(" ");
            }
        }

        // Output the reversed sentence
        System.out.println(reversedSentence.toString());
    }
}


import java.util.Scanner;

public class WordCounter {

    // Function to count occurrences of a word in a sentence
    public static int countOccurrences(String word, String sentence) {
        // Convert both the word and sentence to lower case to ignore case differences
        word = word.toLowerCase();
        sentence = sentence.toLowerCase();

        // Split the sentence into words
        String[] words = sentence.split("\\s+");

        int count = 0;
        // Count occurrences of the word
        for (String w : words) {
            if (w.equals(word)) {
                count++;
            }
        }

        return count;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the word
        System.out.print("Enter a word: ");
        String word = scanner.next();

        // Consume the newline left-over
        scanner.nextLine();

        // Input the sentence
        System.out.print("Enter a sentence: ");
        String sentence = scanner.nextLine();

        // Get the count of occurrences
        int count = countOccurrences(word, sentence);

        // Display the result
        System.out.println("The word '" + word + "' appears " + count + " times in the sentence.");

        scanner.close();
    }
}

3. Write a program to remove all even numbers from an ArrayList and display.

Code:-

import java.util.ArrayList;
import java.util.Iterator;

public class RemoveEvenNumbers {
    public static void main(String[] args) {
        // Sample ArrayList with integers
        ArrayList<Integer> arrayList = new ArrayList<>();
        arrayList.add(1);
        arrayList.add(2);
        arrayList.add(3);
        arrayList.add(4);
        arrayList.add(5);
        arrayList.add(6);
        arrayList.add(7);
        arrayList.add(8);
        arrayList.add(9);
        arrayList.add(10);

        // Print the original ArrayList
        System.out.println("Original ArrayList: " + arrayList);

        // Remove even numbers using an Iterator
        Iterator<Integer> iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            Integer number = iterator.next();
            if (number % 2 == 0) {
                iterator.remove();
            }
        }

        // Print the ArrayList after removing even numbers
        System.out.println("ArrayList after removing even numbers: " + arrayList);
    }
}


2. Write a program to create a HashSet by inputting 10 strings and search a particular string in the set and display proper message.

Code:-

import java.util.HashSet;
import java.util.Scanner;

public class HashSetSearch {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HashSet<String> stringSet = new HashSet<>();

        // Input 10 strings from the user
        System.out.println("Please enter 10 strings:");
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter string " + (i + 1) + ": ");
            String input = scanner.nextLine();
            stringSet.add(input);
        }

        // Search for a particular string in the set
        System.out.print("Enter the string to search for: ");
        String searchString = scanner.nextLine();

        // Check if the string is in the set and display appropriate message
        if (stringSet.contains(searchString)) {
            System.out.println("The string \"" + searchString + "\" is present in the set.");
        } else {
            System.out.println("The string \"" + searchString + "\" is not present in the set.");
        }

        scanner.close();
    }
}
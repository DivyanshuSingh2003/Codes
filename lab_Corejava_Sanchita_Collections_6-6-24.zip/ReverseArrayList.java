4. Write a program to reverse the order of elements in an ArrayList. (Hint: Use a loop or recursion)

Code:-

import java.util.ArrayList;
import java.util.Collections;

public class ReverseArrayList {
    public static void main(String[] args) {
        // Sample ArrayList with integers
        ArrayList<Integer> arrayList = new ArrayList<>();
        arrayList.add(1);
        arrayList.add(2);
        arrayList.add(3);
        arrayList.add(4);
        arrayList.add(5);

        // Print the original ArrayList
        System.out.println("Original ArrayList: " + arrayList);

        // Reverse the ArrayList using Collections.reverse() method
        Collections.reverse(arrayList);

        // Print the reversed ArrayList
        System.out.println("Reversed ArrayList: " + arrayList);
    }
}
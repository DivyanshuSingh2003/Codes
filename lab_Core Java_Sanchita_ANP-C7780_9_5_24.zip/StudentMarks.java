Q.4] The class teacher wants to store the marks obtained in English, Maths and Science of her class having 40 students. Write a program to input marks in Eng, Science and Maths by using three single dimensional arrays. Calculate and print the following information: (i) Average marks secured by each student. (ii) Class average in each subject. [Hint: Class average is the average marks obtained by 40 students in a particular subject.
Code:-


import java.util.Scanner;

public class StudentMarks {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Arrays to store marks of each subject for 40 students
        int[] englishMarks = new int[40];
        int[] mathMarks = new int[40];
        int[] scienceMarks = new int[40];

        // Input marks for each subject for each student
        for (int i = 0; i < 40; i++) {
            System.out.println("Enter marks for student " + (i + 1) + ":");
            System.out.print("English: ");
            englishMarks[i] = scanner.nextInt();
            System.out.print("Maths: ");
            mathMarks[i] = scanner.nextInt();
            System.out.print("Science: ");
            scienceMarks[i] = scanner.nextInt();
        }
        scanner.close();

        // Calculate and print average marks secured by each student
        System.out.println("\nAverage marks secured by each student:");
        for (int i = 0; i < 40; i++) {
            double average = (englishMarks[i] + mathMarks[i] + scienceMarks[i]) / 3.0;
            System.out.println("Student " + (i + 1) + ": " + average);
        }

        // Calculate and print class average in each subject
        double englishClassAverage = calculateClassAverage(englishMarks);
        double mathClassAverage = calculateClassAverage(mathMarks);
        double scienceClassAverage = calculateClassAverage(scienceMarks);

        System.out.println("\nClass average in each subject:");
        System.out.println("English: " + englishClassAverage);
        System.out.println("Maths: " + mathClassAverage);
        System.out.println("Science: " + scienceClassAverage);
    }

    // Function to calculate class average in a particular subject
    public static double calculateClassAverage(int[] marks) {
        double sum = 0;
        for (int mark : marks) {
            sum += mark;
        }
        return sum / marks.length;
    }
}

Q.6] Write a program to input a number and check whether it is a Kaprekar number or not. Take a positive whole number n that has d number of digits. Take the square n and separate the result into two pieces: a right-hand piece that has d digits and a left-hand piece that has either d or d-1 digits. Add these two pieces together. If the result is n, then n is a Kaprekar number. Examples are 9 (92 = 81, 8 + 1 = 9), 45 (452 = 2025, 20 + 25 = 45), and 297 (2972 = 88209, 88 + 209 = 297)
Code:-

import java.util.Scanner;

public class KaprekarNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input a number
        System.out.print("Enter a positive whole number: ");
        int number = scanner.nextInt();
        scanner.close();

        // Check if it's a Kaprekar number
        if (isKaprekarNumber(number)) {
            System.out.println(number + " is a Kaprekar number.");
        } else {
            System.out.println(number + " is not a Kaprekar number.");
        }
    }

    public static boolean isKaprekarNumber(int number) {
        long square = (long) number * number;
        String squareStr = String.valueOf(square);
        int length = squareStr.length();

        for (int i = 1; i < length; i++) {
            String left = squareStr.substring(0, i);
            String right = squareStr.substring(i);

            int leftNum = (left.isEmpty()) ? 0 : Integer.parseInt(left);
            int rightNum = (right.isEmpty()) ? 0 : Integer.parseInt(right);

            if (leftNum + rightNum == number) {
                return true;
            }
        }

        return false;
    }
}

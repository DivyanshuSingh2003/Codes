
Q.2] Write a program to input 10 integers and find the sum of two-digit as well as three-digit numbers separately.
code:-


import java.util.Scanner;

public class NumberSumCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[10];
        int sumTwoDigit = 0;
        int sumThreeDigit = 0;

        System.out.println("Enter 10 integers:");
        for (int i = 0; i < 10; i++) {
            numbers[i] = scanner.nextInt();
            if (isTwoDigit(numbers[i])) {
                sumTwoDigit += numbers[i];
            } else if (isThreeDigit(numbers[i])) {
                sumThreeDigit += numbers[i];
            }
        }
        scanner.close();

        System.out.println("Sum of two-digit numbers: " + sumTwoDigit);
        System.out.println("Sum of three-digit numbers: " + sumThreeDigit);
    }

    public static boolean isTwoDigit(int number) {
        return number >= 10 && number <= 99;
    }

    public static boolean isThreeDigit(int number) {
        return number >= 100 && number <= 999;
    }
}

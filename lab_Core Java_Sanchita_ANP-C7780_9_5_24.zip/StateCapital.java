import java.util.Scanner;

Q.5] Write a program to accept 10 states and 10 capitals of country in two different single dimensional array. Now, enter a state of the country to display its capital. If it is present then display its capital otherwise, display a relevant message. Sample input: enter the state and the capital Bihar Patna West Bengal Kolkata and so on------------
sample Output: enter the state whose capital is to be searched: West Bengal The capital is Kolkata.
Code:-

public class StateCapital {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Arrays to store states and capitals
        String[] states = new String[10];
        String[] capitals = new String[10];

        // Input states and capitals
        System.out.println("Enter the names of 10 states and their capitals:");
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter state " + (i + 1) + ": ");
            states[i] = scanner.nextLine();
            System.out.print("Enter capital for " + states[i] + ": ");
            capitals[i] = scanner.nextLine();
        }

        // Input the state to search for its capital
        System.out.print("\nEnter the state whose capital is to be searched: ");
        String stateToSearch = scanner.nextLine();

        // Search for the state and display its capital if found
        boolean found = false;
        for (int i = 0; i < 10; i++) {
            if (states[i].equalsIgnoreCase(stateToSearch)) {
                System.out.println("The capital is: " + capitals[i]);
                found = true;
                break;
            }
        }

        // If state not found, display relevant message
        if (!found) {
            System.out.println("State not found or capital information not available.");
        }

        scanner.close();
    }
}

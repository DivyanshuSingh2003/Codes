Q.1] Wap to input a number and check whether its buzz no or not.(Buzz no ends with 7 and divisible by 7) eg: 77
code:-

import java.util.Scanner;

public class BuzzNumberChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = scanner.nextInt();
        scanner.close();
        
        if (isBuzzNumber(number)) {
            System.out.println(number + " is a buzz number.");
        } else {
            System.out.println(number + " is not a buzz number.");
        }
    }
    
    public static boolean isBuzzNumber(int number) {
        // Check if the number ends with 7 and is divisible by 7
        return (number % 10 == 7) && (number % 7 == 0);
    }
}
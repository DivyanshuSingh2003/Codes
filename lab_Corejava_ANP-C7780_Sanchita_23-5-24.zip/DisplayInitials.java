6.Write a program in Java to accept a name(Containing three words) and display only the initials (i.e., first letter of each word).

Sample Input: LAL KRISHNA ADVANI

Sample Output: L K A

Code:-


import java.util.Scanner;

public class DisplayInitials {
    public static void main(String[] args) {
        // Create a Scanner object for taking input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a name with three words
        System.out.println("Enter a name (containing three words):");
        String input = scanner.nextLine();

        // Call the method to get initials and store the result
        String initials = getInitials(input);

        // Display the initials
        System.out.println("Initials: " + initials);

        // Close the scanner
        scanner.close();
    }

    // Method to get the initials from a name with three words
    public static String getInitials(String name) {
        // Split the input string into words
        String[] words = name.split(" ");

        // Check if there are exactly three words
        if (words.length != 3) {
            return "Invalid input. Please enter exactly three words.";
        }

        // Get the first letter of each word and concatenate them
        String initials = words[0].charAt(0) + " " + words[1].charAt(0) + " " + words[2].charAt(0);

        // Convert the initials to uppercase
        initials = initials.toUpperCase();

        // Return the initials
        return initials;
    }
}
5.Write a program in Java to accept a word/a String and display the new string after removing all the vowels present in it.
Code:-

import java.util.Scanner;

public class RemoveVowels {
    public static void main(String[] args) {
        // Create a Scanner object for taking input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a string
        System.out.print("Enter a word or a string: ");
        String input = scanner.nextLine();

        // Call the method to remove vowels and get the result
        String result = removeVowels(input);

        // Display the result
        System.out.println("String after removing vowels: " + result);

        // Close the scanner
        scanner.close();
    }

    // Method to remove vowels from a given string
    public static String removeVowels(String str) {
        // Define a string containing all vowels (both uppercase and lowercase)
        String vowels = "AEIOUaeiou";

        // Create a StringBuilder to build the resulting string
        StringBuilder result = new StringBuilder();

        // Iterate through each character in the input string
        for (int i = 0; i < str.length(); i++) {
            // Get the current character
            char c = str.charAt(i);

            // Check if the current character is not a vowel
            if (vowels.indexOf(c) == -1) {
                // If it's not a vowel, append it to the result
                result.append(c);
            }
        }

        // Convert the StringBuilder to a string and return it
        return result.toString();
    }
}
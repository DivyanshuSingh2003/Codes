4. Write a program to create an array of strings and sort them in a ascending order.
Code:-


import java.util.Arrays;

public class StringSorter {
    public static void main(String[] args) {
        // create an array of strings
        String[] strings = {"apple", "orange", "banana", "pear", "grape"};

        //Print the array before sorting
        System.out.println("Before Sorting: ");
        for (String s : strings) {
            System.out.println(s);
        }

        // sort the array in ascending order
        Arrays.sort(strings);

        //print the array after sorting
        System.out.println("\n after sorting:");
        for (String s : strings) {
            System.out.println(s);
        }
    }
}
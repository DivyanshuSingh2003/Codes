2.Write a program to input a sentence and count number of vowels , digits , words and special characters.
Code:-

import java.sql.SQLOutput;
import java.util.Scanner;

public class CountVolsSplDig {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String str;
        int vol=0, spl=0, dig=0, word=0;

	// Input the string
        System.out.print("Enter a String: ");
        str = sc.nextLine();

        str = " " + str; // to read the first word
        str = str.toLowerCase();

        for (int i=0; i<str.length(); i++)
        {
            char ch = str.charAt(i);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') //check if it is a vowel
                vol++; //increment the vowel

            if (ch>='0' && ch<'9') // check if it is a digit
                dig++; //incrementing if it is digits

            if (ch == ' ') //check how many spaces are in a string.
                word++; //increment the words after the space

            if (!Character.isLetterOrDigit(ch)&&!Character.isWhitespace(ch)) //check if it a special character.
                spl++; //Increment the spl characters
        }

        System.out.println("Vowels are: " + vol);
        System.out.println("Digits are: "+dig);
        System.out.println("Words are: "+word);
        System.out.println("Special Characters are: " + spl);
    }
}
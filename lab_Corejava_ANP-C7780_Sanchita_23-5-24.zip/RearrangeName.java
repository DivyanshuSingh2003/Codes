7.Write a program in Java to accept a name containing three words and display the surname first, followed by the first and middle names.

Sample Input: MOHANDAS KARAMCHAND GANDHI
Sample Output: GANDHI MOHANDAS KARAMCHAND

Code:-

import java.util.Scanner;

public class RearrangeName {
    public static void main(String[] args) {
        // Create a Scanner object for taking input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a name with three words
        System.out.println("Enter a name (containing three words):");
        String input = scanner.nextLine();

        // Call the method to rearrange the name and store the result
        String rearrangedName = rearrangeName(input);

        // Display the rearranged name
        System.out.println("Rearranged Name: " + rearrangedName);

        // Close the scanner
        scanner.close();
    }

    // Method to rearrange the name with surname first
    public static String rearrangeName(String name) {
        // Split the input string into words
        String[] words = name.split(" ");

        // Check if there are exactly three words
        if (words.length != 3) {
            return "Invalid input. Please enter exactly three words.";
        }

        // Rearrange the words to have the surname first
        String rearrangedName = words[2] + " " + words[0] + " " + words[1];

        // Return the rearranged name
        return rearrangedName;
    }
}

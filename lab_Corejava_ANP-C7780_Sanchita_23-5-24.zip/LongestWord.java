3.Write a program to input a sentence and find the longest word.
Code:-

import java.util.Scanner;

public class LongestWord {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String str,word,lword;
	
	//Take the input from the user.
        System.out.print("Enter a String: ");
        str = sc.nextLine();

        word ="";
        lword ="";
        str = str+" "; //read the last word

        for (int i=0; i<str.length(); i++)
        {
            char ch = str.charAt(i);
            if (ch==' ') {
                if (word.length() > lword.length()) //compare two word
                    lword = word;
                word = "";
            }
            else
                word=word+ch;
        }
        System.out.println("The Longest word is "+lword+" and has length "+lword.length());
    }
}
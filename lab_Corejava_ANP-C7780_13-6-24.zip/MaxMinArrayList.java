2. Find the maximum and minimum elements in an ArrayList.

Code:-

import java.util.ArrayList;
import java.util.Collections;

public class MaxMinArrayList {

    public static void main(String[] args) {
        // Create an ArrayList and add some elements
        ArrayList<Integer> list = new ArrayList<>();
        list.add(10);
        list.add(5);
        list.add(30);
        list.add(25);
        list.add(15);

        // Find the maximum element
        int maxElement = Collections.max(list);
        // Find the minimum element
        int minElement = Collections.min(list);

        // Print the results
        System.out.println("Maximum element: " + maxElement);
        System.out.println("Minimum element: " + minElement);
    }
}

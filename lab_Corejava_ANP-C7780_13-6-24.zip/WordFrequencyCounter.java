1. Count the frequency of each word in a string using a HashMap.

Code:- 

import java.util.HashMap;
import java.util.Map;

public class WordFrequencyCounter {

    public static void main(String[] args) {
        String text = "This is a test. This test is only a test.";

        // Call the function to count word frequency
        Map<String, Integer> wordFrequency = countWordFrequency(text);

        // Print the word frequencies
        for (Map.Entry<String, Integer> entry : wordFrequency.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    public static Map<String, Integer> countWordFrequency(String text) {
        // Remove punctuation and convert to lowercase
        text = text.replaceAll("[^a-zA-Z ]", "").toLowerCase();

        // Split the string into words
        String[] words = text.split("\\s+");

        // Create a HashMap to store the word frequency
        Map<String, Integer> wordCountMap = new HashMap<>();

        // Iterate through the words
        for (String word : words) {
            // If the word is already in the map, increment its count
            if (wordCountMap.containsKey(word)) {
                wordCountMap.put(word, wordCountMap.get(word) + 1);
            } else {
                // Otherwise, add the word to the map with a count of 1
                wordCountMap.put(word, 1);
            }
        }

        return wordCountMap;
    }
}

//.St. Xavier School displays a notice on the school notice board regarding admission in Std. XI for choosing different streams, according to marks obtained in English, Maths and Science in ICSE Examinations.

code:-

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your Percentage to choose the Field: ");
        int x = sc.nextInt();
            System.out.print("Enter your marks in English: ");
            int eng = sc.nextInt();
            System.out.print("Enter your marks in Science: ");
            int sci = sc.nextInt();
            System.out.print("Enter your marks in Maths: ");
            int mat = sc.nextInt();

        if (eng >= 80 && mat >= 80 && sci >= 80) {
            System.out.println("You can Choose Pure Science");
        } else if (eng >= 80 && sci >= 80 || mat >= 60) {
            System.out.println("You can Choose Bio Science");
        } else if (eng >= 60 && mat >= 60 && sci >= 60) {
            System.out.println("You can Choose Commerce");
        } else if (x <= 0 && x < 100) {
            System.out.println("Error");
        } else {
            System.out.println("Better luck next time");
        }
    }
}
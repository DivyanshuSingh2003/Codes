import java.util.Scanner;
class Main {
         public static void main(String args[]) {
                Scanner s=new Scanner(System.in);

  System.out.println("1.Perimeter of a Square");
  System.out.println("2.Perimeter of a Rectangle");
  System.out.println("3.Perimeter of a Circle");
  
                System.out.println("Enter your option:");
                int op=s.nextInt();

                switch(op)
                {

                     case 1: System.out.print("Enter side: ");
                                  int x=s.nextInt();
                                  int side=4*x;
                                 System.out.println("Perimeter of a square is :"+side);
                                 break;

                    case 2: System.out.print("Enter the side :");
                                  int l=s.nextInt();
                                  int b=s.nextInt();
                                  int per=2*(l+b);
                                 System.out.println("Perimeter of a rectangle is:"+per);
                                 break;

                      case 3: System.out.println("Enter radius:");
                                  float r=s.nextFloat();
                                  float ac=2*3.14f*r;
                                 System.out.print("Perimeter of a circle is :"+ac);
                                 break;

                     default:System.out.exit(0);
                    }
                 }
}
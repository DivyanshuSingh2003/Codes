2. Write a program to show multithreading in java.

Code:-

// Creating a class that extends Thread
class MyThread extends Thread {
    private String threadName;
    
    MyThread(String name) {
        threadName = name;
    }

    // The run method contains the code that constitutes the new thread
    public void run() {
        try {
            for (int i = 1; i <= 5; i++) {
                System.out.println(threadName + " - Count: " + i);
                // Let the thread sleep for a while
                Thread.sleep(500);
            }
        } catch (InterruptedException e) {
            System.out.println(threadName + " interrupted.");
        }
        System.out.println(threadName + " exiting.");
    }
}

// Creating a class that implements Runnable
class MyRunnable implements Runnable {
    private String threadName;
    
    MyRunnable(String name) {
        threadName = name;
    }

    // The run method contains the code that constitutes the new thread
    public void run() {
        try {
            for (int i = 1; i <= 5; i++) {
                System.out.println(threadName + " - Count: " + i);
                // Let the thread sleep for a while
                Thread.sleep(500);
            }
        } catch (InterruptedException e) {
            System.out.println(threadName + " interrupted.");
        }
        System.out.println(threadName + " exiting.");
    }
}

public class Main {
    public static void main(String[] args) {
        // Creating instances of both MyThread and MyRunnable
        MyThread thread1 = new MyThread("Thread-1");
        Thread thread2 = new Thread(new MyRunnable("Thread-2"));
        
        // Starting both threads
        thread1.start();
        thread2.start();
        
        // Ensuring main thread waits for other threads to finish
        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }

        System.out.println("Main thread exiting.");
    }
}

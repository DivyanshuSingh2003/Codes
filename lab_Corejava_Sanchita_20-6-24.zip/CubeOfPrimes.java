5. Write a program to input an array 10 elements and print the cube of prime numbers in it.

Code:-

import java.util.Scanner;

public class CubeOfPrimes {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] array = new int[10];

        // Input 10 elements from the user
        System.out.println("Enter 10 elements:");
        for (int i = 0; i < 10; i++) {
            array[i] = scanner.nextInt();
        }

        // Print the cube of prime numbers
        System.out.println("Cubes of prime numbers in the array:");
        for (int i = 0; i < 10; i++) {
            if (isPrime(array[i])) {
                System.out.println("Number: " + array[i] + ", Cube: " + (int) Math.pow(array[i], 3));
            }
        }
    }

    // Method to check if a number is prime
    public static boolean isPrime(int num) {
        // Handle numbers less than 2
        if (num < 2) {
            return false;
        }
        // Check divisibility from 2 to the square root of num
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}

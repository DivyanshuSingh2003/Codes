4. Create a double dimensional array 3X3 and find the sum and product.

Code:-

public class ArraySumAndProduct {

    public static void main(String[] args) {
        // Initialize a 3x3 double-dimensional array
        int[][] array = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        // Call methods to calculate the sum and product
        int sum = findSum(array);
        long product = findProduct(array);

        // Print the results
        System.out.println("Sum of all elements: " + sum);
        System.out.println("Product of all elements: " + product);
    }

    // Method to calculate the sum of all elements in the 2D array
    public static int findSum(int[][] array) {
        int sum = 0;
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                sum += array[i][j];
            }
        }
        return sum;
    }

    // Method to calculate the product of all elements in the 2D array
    public static long findProduct(int[][] array) {
        long product = 1;
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                product *= array[i][j];
            }
        }
        return product;
    }
}

6. Write a program to show  JDBC connection with MYSQL and perform the following operations:
Create table Customer with following fields:
Custno, Custame, Custaddress, Phoneno, City, Pincode, Country, 
Insert 10 row and display it in the console.

Code:-

package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CustomerDatabase {

    public static void main(String[] args) {
        // Database connection details
        String jdbcURL = "jdbc:mysql://localhost:3306/Customer";
        String username = "root";
        String password = "@divyanshu12";

        try {
            // Establish connection to the database
            Connection connection = DriverManager.getConnection(jdbcURL, username, password);
            Statement statement = connection.createStatement();

            // Create the Customer table
            String createTableSQL = "CREATE TABLE IF NOT EXISTS Customer (" +
                                    "Custno INT PRIMARY KEY," +
                                    "Custname VARCHAR(50)," +
                                    "Custaddress VARCHAR(100)," +
                                    "Phoneno VARCHAR(15)," +
                                    "City VARCHAR(50)," +
                                    "Pincode VARCHAR(10)," +
                                    "Country VARCHAR(50))";
            statement.executeUpdate(createTableSQL);

            // Insert 10 rows into the Customer table
            String insertRowsSQL = "INSERT INTO Customer (Custno, Custname, Custaddress, Phoneno, City, Pincode, Country) VALUES " +
                                   "(1, 'John Doe', '123 Elm Street', '1234567890', 'Springfield', '12345', 'USA'), " +
                                   "(2, 'Jane Smith', '456 Oak Avenue', '2345678901', 'Shelbyville', '23456', 'USA'), " +
                                   "(3, 'Jim Brown', '789 Pine Road', '3456789012', 'Ogdenville', '34567', 'USA'), " +
                                   "(4, 'Jake White', '101 Maple Street', '4567890123', 'Capitol City', '45678', 'USA'), " +
                                   "(5, 'Jill Black', '202 Birch Lane', '5678901234', 'North Haverbrook', '56789', 'USA'), " +
                                   "(6, 'Jenny Green', '303 Cedar Boulevard', '6789012345', 'Monroe', '67890', 'USA'), " +
                                   "(7, 'Jeff Blue', '404 Walnut Drive', '7890123456', 'East Nowhere', '78901', 'USA'), " +
                                   "(8, 'Joan Red', '505 Ash Court', '8901234567', 'West Nowhere', '89012', 'USA'), " +
                                   "(9, 'Jerry Yellow', '606 Cherry Street', '9012345678', 'South Haverbrook', '90123', 'USA'), " +
                                   "(10, 'Janet Purple', '707 Peach Way', '0123456789', 'North Nowhere', '01234', 'USA')";
            statement.executeUpdate(insertRowsSQL);

            // Retrieve and display the data from the Customer table
            String selectSQL = "SELECT * FROM Customer";
            ResultSet resultSet = statement.executeQuery(selectSQL);

            while (resultSet.next()) {
                int custno = resultSet.getInt("Custno");
                String custname = resultSet.getString("Custname");
                String custaddress = resultSet.getString("Custaddress");
                String phoneno = resultSet.getString("Phoneno");
                String city = resultSet.getString("City");
                String pincode = resultSet.getString("Pincode");
                String country = resultSet.getString("Country");

                System.out.println("Custno: " + custno + ", Custname: " + custname + ", Custaddress: " + custaddress +
                                   ", Phoneno: " + phoneno + ", City: " + city + ", Pincode: " + pincode + ", Country: " + country);
            }

            // Close the connections
            resultSet.close();
            statement.close();
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


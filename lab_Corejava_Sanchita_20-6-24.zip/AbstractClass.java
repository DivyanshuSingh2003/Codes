1. Create an abstract class Animal and an abstract method makesound () and inherit Animal in Dog class and implement abstract method. (Abstract class can contain non-abstract methods also)

Code:-

// Abstract class Animal
abstract class Animal {
    // Abstract method (does not have a body)
    public abstract void makeSound();

    // Non-abstract method
    public void eat() {
        System.out.println("This animal is eating.");
    }
}

// Dog class that extends Animal
class Dog extends Animal {
    // Implement the abstract method makeSound()
    @Override
    public void makeSound() {
        System.out.println("Woof woof!");
    }
}

// Main class to test the functionality
public class Main {
    public static void main(String[] args) {
        // Create an instance of Dog
        Dog myDog = new Dog();
        
        // Call the makeSound() method
        myDog.makeSound();
        
        // Call the non-abstract method eat()
        myDog.eat();
    }
}


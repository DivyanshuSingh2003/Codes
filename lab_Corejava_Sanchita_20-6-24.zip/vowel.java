3. Write a program to

     i.  input a sentence and replace vowel with its next letter.
	
	Code:-

	import java.util.Scanner;

public class ReplaceVowelWithNextLetter {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input a sentence from the user
        System.out.println("Enter a sentence:");
        String sentence = scanner.nextLine();

        // Replace each vowel with its next letter
        String result = replaceVowelWithNextLetter(sentence);

        // Display the modified sentence
        System.out.println("Modified sentence: " + result);
    }

    public static String replaceVowelWithNextLetter(String sentence) {
        // Convert the sentence to a char array
        char[] chars = sentence.toCharArray();

        for (int i = 0; i < chars.length; i++) {
            char c = chars[i];
            // Check if the character is a vowel
            if (isVowel(c)) {
                // Replace the vowel with its next letter
                chars[i] = (char) (c + 1);
            }
        }

        return new String(chars);
    }

    public static boolean isVowel(char c) {
        // Convert to lowercase to handle both uppercase and lowercase vowels
        c = Character.toLowerCase(c);
        return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
    }
}




     ii.     input a sentence replace vowel with its next vowel.

	Code:-

	import java.util.Scanner;

public class ReplaceVowelWithNextVowel {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input a sentence from the user
        System.out.println("Enter a sentence:");
        String sentence = scanner.nextLine();

        // Replace each vowel with the next vowel
        String result = replaceVowelWithNextVowel(sentence);

        // Display the modified sentence
        System.out.println("Modified sentence: " + result);
    }

    public static String replaceVowelWithNextVowel(String sentence) {
        // Convert the sentence to a char array
        char[] chars = sentence.toCharArray();

        for (int i = 0; i < chars.length; i++) {
            char c = chars[i];
            // Check if the character is a vowel
            if (isVowel(c)) {
                // Replace the vowel with the next vowel
                chars[i] = getNextVowel(c);
            }
        }

        return new String(chars);
    }

    public static boolean isVowel(char c) {
        // Convert to lowercase to handle both uppercase and lowercase vowels
        c = Character.toLowerCase(c);
        return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
    }

    public static char getNextVowel(char c) {
        // Map each vowel to its next vowel
        switch (Character.toLowerCase(c)) {
            case 'a': return 'e';
            case 'e': return 'i';
            case 'i': return 'o';
            case 'o': return 'u';
            case 'u': return 'a';
            default: return c;
        }
    }
}

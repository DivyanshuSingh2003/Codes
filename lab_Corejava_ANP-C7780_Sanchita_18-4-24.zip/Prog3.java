import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get the temperature from the user.
        System.out.println("Enter the temperature: ");
        double temperature = scanner.nextDouble();

        // Get the conversion type from the user.
        System.out.println("Enter the conversion type (F to C or C to F): ");
        String conversionType = scanner.next();

        // Convert the temperature based on the user's input.
        double convertedTemperature;
        if (conversionType.equals("F to C")) {
            convertedTemperature = (temperature - 32) * 5 / 9;
        } else if (conversionType.equals("C to F")) {
            convertedTemperature = (temperature * 9 / 5) + 32;
        } else {
            System.out.println("Invalid conversion type.");
            return;
        }

        // Print the converted temperature.
        System.out.println("The converted temperature is: " + convertedTemperature);
    }
}
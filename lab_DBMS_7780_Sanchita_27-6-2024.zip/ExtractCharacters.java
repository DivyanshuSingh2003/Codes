1. 2. Write a program to extract only character from a string.
Eg: Af02284khff -> Afkhff

Code:-

public class ExtractCharacters {
    public static void main (String[] args) {
        String input = "Af02284khff";
        String result = extractCharacters(input);
        System.out.println("Original string: " + input);
        System.out.println("Extracted characters: " + result);
    }

    // Method to extract only alphabetic characters from a string
    public static String extractCharacters(String str) {
        StringBuilder extracted = new StringBuilder();
        
        // Loop through each character in the string
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            // Check if the character is alphabetic
            if (Character.isLetter(ch)) {
                extracted.append(ch); // Add character to the result
            }
        }
        
        return extracted.toString();
    }
}

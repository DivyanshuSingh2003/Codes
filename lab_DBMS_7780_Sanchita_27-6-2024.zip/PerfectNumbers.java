1. Display all perfect numbers between 1 to 1000.
(perfect no : sum of the factors is the number itself eg: 6: 1+2+3=6).

Code:-

public class PerfectNumbers {
    public static void main(String[] args) {
        System.out.println("Perfect numbers between 1 and 1000:");
        
        // Loop through numbers from 1 to 1000
        for (int number = 1; number <= 1000; number++) {
            // Check if the current number is perfect
            if (isPerfect(number)) {
                // Print the perfect number
                System.out.println(number);
            }
        }
    }

    // Method to check if a number is perfect
    public static boolean isPerfect(int number) {
        int sum = 0;
        
        // Find and sum all divisors of the number
        for (int i = 1; i <= number / 2; i++) {
            if (number % i == 0) {
                sum += i; // Add divisor to sum
            }
        }
        
        // A number is perfect if it is equal to the sum of its proper divisors
        return sum == number;
    }
}

